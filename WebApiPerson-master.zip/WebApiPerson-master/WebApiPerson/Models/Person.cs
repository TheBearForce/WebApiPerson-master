﻿namespace WebApiPerson.Models
{
    public class Person
    {
        public int ID { get; set; }

        public required string NAME { get; set; }

        public required int AGE {  get; set; }
    }
}
