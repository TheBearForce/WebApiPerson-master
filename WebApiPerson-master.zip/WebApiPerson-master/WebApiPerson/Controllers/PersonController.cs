﻿namespace WebApiPerson.Controllers
{
    public class PersonController
    {
    }
}
